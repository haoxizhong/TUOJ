#!/bin/sh
rm -rf score/*
rm -rf output/*
make clean
make
./bin/driver
./bin/check
