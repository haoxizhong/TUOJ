// #include "core/graphDB.hpp"
#include "core/graphDB.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <assert.h>

using namespace std;

#define BENCH_FILE "./input/benchmark.txt"
#define FINAL_ANS "./output/final.ans"

class Driver{
private:
	GraphDB * db;
	FILE * f_score = NULL;
	FILE * f_ans = NULL;
	double preprocTime = 0.0f;
public:
	inline Driver();
	inline ~Driver();
	inline void run();
private:
	inline void record(int queryType, vector<vector<string> > & res, double times);		
	inline void queryOneTest(vector<tuple<string, int> > & users);
	inline void queryTwoTest(vector<tuple<string, int> > & users);
	inline void queryThreeTest(vector<tuple<string, string, string, int> > & users);
	inline void queryFourTest(vector<tuple<string, string, int> > & users);
};

inline Driver::Driver(){
	f_ans = fopen(FINAL_ANS, "w");
	double start_time = get_time();
	db = new GraphDB();
	double end_time = get_time();	
	this->preprocTime = end_time - start_time;
	fprintf(f_ans, "%d %d %lf\n", 0, 0, end_time - start_time);
	fflush(f_ans);
}
inline Driver::~Driver(){
	fclose(f_ans);
}

inline void Driver::record(int queryType, vector<vector<string> > & res, double times){
	//Output answer
	fprintf(f_ans, "%d %zd %lf\n", queryType, res.size(), times);
	for (int i = 0; i < res.size(); i++) {
		string str = "";
		for (int j = 0; j < res[i].size(); j++) {
			str += res[i][j];
		}
		fprintf(f_ans, "%s\n", md5(str).c_str());
	}
	fflush(f_ans);
}

/*Query testing*/
inline void Driver::queryOneTest(vector<tuple<string, int> > & users){
	double start_time = get_time();
	vector<vector<string> > res = db->queryOne(users);
	double end_time = get_time();

	//Log to file
	this->record(1, res, end_time - start_time);
}

inline void Driver::queryTwoTest(vector<tuple<string, int> > & users){
	double start_time = get_time();
	vector<vector<string> > res = db->queryTwo(users);
	double end_time = get_time();

	//Log to file
	this->record(2, res, end_time - start_time);
}

inline void Driver::queryThreeTest(
		vector<tuple<string, string, string, int> > & users){
	double start_time = get_time();
	vector<vector<string> > res = db->queryThree(users);
	double end_time = get_time();
	
	//Log to file
	this->record(3, res, end_time - start_time);
}

inline void Driver::queryFourTest(
		vector<tuple<string, string, int> > & users) {
	double start_time = get_time();
	vector<vector<string> > res = db->queryFour(users);
	double end_time = get_time();

	//Log to file
	this->record(4, res, end_time - start_time);
}

/*Running function*/
inline void Driver::run(){
	//1. Load check file
	char buf[256];
	int queryNum = 0, queryType = 0;
	FILE * fp = fopen(BENCH_FILE, "r");
	if (fp == NULL) {
		fprintf(stderr, "Can't open benchmark file\n");
		exit(-1);
	}
	while (!feof(fp)) {
		if(fscanf(fp, "%d %d", &queryType, &queryNum) != 2) break;
		if (queryType >= 1 && queryType <= 2) {
			string uid;
			char uidStr[256];
			int top;
			vector<tuple<string, int> > users;
			//Read benchmark
			for (int i = 0; i < queryNum; i++) {
				assert(fscanf(fp, "%s %d", uidStr, &top) == 2);
				uid = uidStr;
				users.emplace_back(uid, top);
			}
			if (queryType == 1) this->queryOneTest(users);
			else this->queryTwoTest(users);
		} else if (queryType == 3){
			string uid, startTime, endTime, answer;
			char uidStr[256];
			char startTimeStr[256];
			char endTimeStr[256];
			int top;
			vector<tuple<string, string, string, int> > users;
			//Read benchmark
			for (int i = 0; i < queryNum; i++) {
				assert(fscanf(fp, "%s %s %s %d", uidStr, 
							startTimeStr, endTimeStr, &top) == 4);
				
				uid = uidStr;
				startTime = startTimeStr; endTime = endTimeStr;
				users.emplace_back(uid, startTime, endTime, top);
			}
			this->queryThreeTest(users);
		} else if (queryType == 4) { 
			string startTime, endTime;
			char startTimeStr[256];
			char endTimeStr[256];
			int top;
			vector<tuple<string, string, int> > users;
			//Read benchmark
			for (int i = 0; i < queryNum; i++) {
				assert(fscanf(fp, "%s %s %d", startTimeStr, endTimeStr, &top) == 3);
				startTime = startTimeStr; endTime = endTimeStr;
				//cout <<  startTime <<" " << endTime << endl;
				users.emplace_back(startTime, endTime, top);
			}
			//cout << queryType << " " << queryNum << endl;
			this->queryFourTest(users);
		} else printf("Query type %d is not defined!!\n", queryType);
	}

	fclose(fp);
}

int main(int argc, char ** argv){
	Driver driver;
	driver.run();
	return 0;
}
