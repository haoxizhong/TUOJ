#include "core/graphDB.hpp"

#define USER_ANS "./output/final.ans"
#define CHECK_ANS "./answer/check.ans"
#define FINAL_SCORE "./score/final.score"
#define QUERY_NUM 5 //Include preprocessing

struct Result{
	int type;
	int total;
	int correct;
	double times;
	vector<string> answers;
	Result(int _type, int _total): type(_type), total(_total) {}
	Result(int _type, int _total, double _times)
		: type(_type), total(_total), times(_times) {}
	Result(int _type, int _total, int _correct, double _times)
		: type(_type), total(_total), correct(_correct), times(_times) {}
};

class Check{
private:
	vector<Result> v_user_ans;
	vector<Result> v_check_ans;
	double preprc_time = 0.0f;
public:
	inline Check();
	inline ~Check();
	inline void run();

private:
	inline void calc_score();
};

inline Check::Check(){
	for (int i = 0 ; i < QUERY_NUM; i++) {
		this->v_user_ans.emplace_back(i, 0, 0, 0);
		this->v_check_ans.emplace_back(i, 0, 0, 0);
	}
}

inline Check::~Check(){
}

inline void Check::run(){
	//Reading answers
	FILE * f_check_ans = fopen(CHECK_ANS, "r");
	if (f_check_ans == NULL) {
		fprintf(stderr, "Can not open check answers' file\n");
		exit(-1);
	}

	int query_type, query_num;
	char answer[256];
	while(!feof(f_check_ans)) {
		if(fscanf(f_check_ans, "%d %d", &query_type, &query_num) != 2) break;
		if (query_type < 0 || query_type > 4){
			fprintf(stderr, "Can't recognise this query type %d\n", query_type);
			exit(-1);
		}
		this->v_check_ans[query_type].total = query_num;
		for (int i = 0; i < query_num; i ++) {
			assert(fscanf(f_check_ans, "%s", answer) == 1);
			this->v_check_ans[query_type].answers.emplace_back(answer);
		}
	}
	fclose(f_check_ans);

	FILE * f_user_ans = fopen(USER_ANS, "r");
	if (f_user_ans == NULL) {
		fprintf(stderr, "Can not open user answers' file\n");
		exit(-1);
	}
	double times;
	while (!feof(f_user_ans)) {
		if (fscanf(f_user_ans, "%d %d %lf", &query_type, &query_num, &times) != 3) break;
		if (query_type < 0 || query_type > 4){
			fprintf(stderr, "Can't recognise this query type %d\n", query_type);
			exit(-1);
		}
		this->v_user_ans[query_type].total = query_num;
		this->v_user_ans[query_type].times = times;
		for (int i = 0; i < query_num; i ++) {
			assert(fscanf(f_user_ans, "%s", answer) == 1);
			this->v_user_ans[query_type].answers.emplace_back(answer);
		}	
	}
	fclose(f_user_ans);

	//calculate score
	this->calc_score();
}

inline void Check::calc_score(){
	FILE * f_score = fopen(FINAL_SCORE, "w");
	for (int i = 0 ; i < QUERY_NUM; i++) {
		this->v_check_ans[i].times = this->v_user_ans[i].times;
		if (this->v_check_ans[i].total != this->v_user_ans[i].total){
			this->v_check_ans[i].correct = 0;
		}
		int correct = 0;
		for (int j = 0; j < this->v_user_ans[i].total; j++) {
			if (this->v_check_ans[i].answers[j] == md5(this->v_user_ans[i].answers[j])) correct++;
		}
		this->v_check_ans[i].correct = correct;

		fprintf(f_score, "%d %d %d %lf\n", 
				i, this->v_check_ans[i].total, this->v_check_ans[i].correct, this->v_check_ans[i].times);
		printf("Type:%d, Total: %d, Correct:%d, Times:%lf\n", 
				i, this->v_check_ans[i].total, this->v_check_ans[i].correct, this->v_check_ans[i].times);
	}
	fclose(f_score);
}

int main(int argc, char ** argv){
	Check ck;
	ck.run();
	return 0;
}
