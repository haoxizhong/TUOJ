#!/bin/bash

zip -r ./output/CCSP.zip core/*
