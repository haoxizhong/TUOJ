#ifndef GRAPHDB_H
#define GRAPHDB_H

#include "core/headers.hpp"

class GraphDB{

private:
	/*Input files' path, don't modify!!*/
	const string friend_file = "./input/friendlist.txt";
	const string mention_file = "./input/mention.txt";
	const string microblog_file = "./input/microblog.txt";

	/*Tmp path(Optional), store your temporary files*/
	const string tmp_path = "./tmp/";
public:
	GraphDB();
	~GraphDB();
	
	/*public interface, don't modify!!*/
	vector<vector<string> > queryOne(vector<tuple<string, int> > queries);
	vector<vector<string> > queryTwo(vector<tuple<string, int> > queries);
	vector<vector<string> > queryThree(vector<tuple<string, string, string, int> > queries);
	vector<vector<string> > queryFour(vector<tuple<string, string, int> > queries);

private:
	/*Your private variables*/

private:
	/*Your private functions*/
};

/*Interface implementation*/
inline GraphDB::GraphDB(){

}

inline GraphDB::~GraphDB(){

}

/* Query 1 */
/*
	How to use Tuple: tie(uid, top) = queries[i];
*/
inline vector<vector<string> > GraphDB::queryOne(vector<tuple<string, int> > queries) {
	vector<vector<string> > result;
	return result;
}
/* Query 2 */
inline vector<vector<string> > GraphDB::queryTwo(vector<tuple<string, int> > queries){
	vector<vector<string> > result;
	return result;
}
/* Query 3 */
inline vector<vector<string> > GraphDB::queryThree(vector<tuple<string, string, string, int> > queries){
	vector<vector<string> > result;
	return result;
}

/* Query 4 */
inline vector<vector<string> > GraphDB::queryFour(vector<tuple<string, string, int> > queries){
	vector<vector<string> > result;
	return result;
}

#endif
