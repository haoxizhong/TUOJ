set -x
rm -rf output/*
rm -rf score/*
javac benchmark/Driver.java -classpath '.'
javac benchmark/Check.java -classpath '.'

java benchmark.Driver
java benchmark.Check
