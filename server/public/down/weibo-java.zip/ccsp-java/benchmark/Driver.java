package benchmark;

import java.util.*;
import java.io.*;
import java.text.SimpleDateFormat;
import core.*;

public class Driver {
	private final String BENCH_FILE = "./input/benchmark.txt";
	private final String FINAL_ANS= "./output/final.ans";

	private GraphDB db = null;
	
	public Driver(){
		//Preprocessing Time
		double start_time = this.getTime();
		this.db = new GraphDB();
		double end_time = this.getTime();
		this.record(0, null, end_time - start_time);
	}
	//Running function
	public void run(){
		File benchFile = new File(this.BENCH_FILE);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(benchFile));
			String lineString = null;
			while ((lineString = reader.readLine()) != null) {
				String[] params = lineString.split(" ");
				int queryType = Integer.parseInt(params[0]);
				int queryNum= Integer.parseInt(params[1]);
				if (queryType >= 1 && queryType <= 2) {
					ArrayList<Tuple.Tuple2<String, Integer> > users = 
						new ArrayList<Tuple.Tuple2<String, Integer> >(queryNum);
					ArrayList<String> ans = new ArrayList<String>(queryNum);
					for (int i = 0; i < queryNum; i++) {
						if((lineString = reader.readLine()) == null) {
							System.out.println("Read line error, Please check your answer file");
							System.exit(1);
						}
						params = lineString.split(" ");
						/* 0: uid, 1: top*/
						Tuple.Tuple2<String, Integer> user = Tuple.tuple(params[0], Integer.parseInt(params[1]));
						users.add(user);
					}
					if (queryType == 1) this.queryOneTest(users);
					else this.queryTwoTest(users);
				} else if (queryType == 3) {
					ArrayList<Tuple.Tuple4<String, String, String, Integer> > users = 
						new ArrayList<Tuple.Tuple4<String, String, String, Integer> >(queryNum);
					ArrayList<String> ans = new ArrayList<String>(queryNum);
					for (int i = 0; i < queryNum; i++) {
						if((lineString = reader.readLine()) == null) {
							System.out.println("Read line error, Please check your answer file");
							System.exit(1);
						}
						params = lineString.split(" ");
						/*0: uid, 1: startTime, 2: endTime, 3: top*/
						Tuple.Tuple4<String, String, String, Integer> user = 
							Tuple.tuple(params[0], params[1], params[2], Integer.parseInt(params[3]));
						users.add(user);
					}
					this.queryThreeTest(users);
				} else if (queryType == 4) {
					ArrayList<Tuple.Tuple3<String, String, Integer> > users =
						new ArrayList<Tuple.Tuple3<String, String, Integer> >(queryNum);
					ArrayList<String> ans = new ArrayList<String>(queryNum);
					for (int i = 0; i < queryNum; i++) {
						if((lineString = reader.readLine()) == null) {
							System.out.println("Read line error, Please check your answer file");
							System.exit(1);
						}
						params = lineString.split(" ");
						/*0: uid, 1: startTime, 2: endTime, 3: top*/
						Tuple.Tuple3<String, String, Integer> user = 
							Tuple.tuple(params[0], params[1], Integer.parseInt(params[2]));
						users.add(user);
					}
					this.queryFourTest(users);
				} else {
					System.out.println("Query type is not defined!!");
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try{
					reader.close();
				} catch (IOException e) {}
			}
		}
	}

	private void record(int queryType, ArrayList<ArrayList<String> > res, double times){
		File fs = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fs = new File(FINAL_ANS);
			if(!fs.exists()) fs.createNewFile();
			
			fw = new FileWriter(fs, true);
			bw = new BufferedWriter(fw);
			
			String str;
			if (res == null) {
				str = String.format("%d %d %f", queryType, 0, times);
				//System.out.println(str);
				bw.write(str);
				bw.newLine();
				bw.flush();
			}
			else {
				str = String.format("%d %d %f", queryType, res.size(), times);
				bw.write(str);
				bw.newLine();
				bw.flush();
				for (int i = 0; i < res.size(); i++) {
					String ss = ""; 
					for (int j = 0; j < res.get(i).size(); j++) {
						ss += res.get(i).get(j);
					}
					bw.write(MD5.Encode(ss));
					bw.newLine();
					bw.flush();
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			 e.printStackTrace();
		} finally {
			try {
				bw.close();
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	//Query testing
	private void queryOneTest(ArrayList<Tuple.Tuple2<String, Integer> > users){
		double start_time = this.getTime();
		ArrayList<ArrayList<String> > res = this.db.queryOne(users);
		double end_time = this.getTime();

		//Log to file
		this.record(1, res, end_time - start_time);
	}

	private void queryTwoTest(ArrayList<Tuple.Tuple2<String, Integer> > users) {
		double start_time = this.getTime();
		ArrayList<ArrayList<String> > res = this.db.queryTwo(users);
		double end_time = this.getTime();

		//Log to file
		this.record(2, res, end_time - start_time);
	}

	private void queryThreeTest(ArrayList<Tuple.Tuple4<String, String, String, Integer> > users){
		double start_time = this.getTime();
		ArrayList<ArrayList<String> > res = this.db.queryThree(users);
		double end_time = this.getTime();

		//Log to file
		this.record(3, res, end_time - start_time);
	}

	private void queryFourTest(ArrayList<Tuple.Tuple3<String, String, Integer> > users){
		double start_time = this.getTime();
		ArrayList<ArrayList<String> > res = this.db.queryFour(users);
		double end_time = this.getTime();

		//Log to file
		this.record(4, res, end_time - start_time);
	}

	//Tools function
	public double getTime(){
		return (double)System.currentTimeMillis() / (double)1000;
	}

	public static void main(String[] args) {
		Driver driver = new Driver();
		driver.run();
	}
}
