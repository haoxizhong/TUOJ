package benchmark;

import java.util.*;
import java.io.*;
import core.*;

class Result {
	public int type = 0;
	public int total = 0;
	public int correct = 0;
	public double times = 0;
	ArrayList<String> answers = null;
	public Result(int _type, int _total){
		this.type = _type;
		this.total = _total;
		this.answers = new ArrayList<String>();
	}
	public Result(int _type, int _total, double _times){
		this.type = _type;
		this.total = _total;
		this.times = _times;
		this.answers = new ArrayList<String>();
	}
	public Result(int _type, int _total, int _correct, double _times){
		this.type = _type;
		this.total = _total;
		this.times = _times;
		this.answers = new ArrayList<String>();
	}
}

public class Check{
	private final String USER_ANS = "./output/final.ans";
	private final String CHECK_ANS = "./answer/check.ans";
	private final String FILE_SCORE = "./score/final.score";
	private final int QUERY_NUM = 5; //Include preprocessing

	private ArrayList<Result> a_user_ans;
	private ArrayList<Result> a_check_ans;
	private double preproc_time = 0.0f;
	
	public Check(){
		a_user_ans = new ArrayList<Result>(this.QUERY_NUM);
		a_check_ans= new ArrayList<Result>(this.QUERY_NUM);
		for (int i = 0; i < this.QUERY_NUM; i++) {
			Result res1 = new Result(i, 0, 0, 0);
			Result res2 = new Result(i, 0, 0, 0);
			a_user_ans.add(res1);
			a_check_ans.add(res2);
		}
	}

	public void run(){
		//Loading check answer file
		File checkAnsFile = new File(this.CHECK_ANS);
		BufferedReader checkReader = null;
		try {
			checkReader = new BufferedReader(new FileReader(checkAnsFile));
			String lineString = null;
			while ((lineString = checkReader.readLine()) != null) {
				String[] params = lineString.split(" ");
				if (params.length != 2) {
					System.out.println("The number of params must be 2");
					System.exit(-1);
				}
				int query_type = Integer.parseInt(params[0]);
				int query_num= Integer.parseInt(params[1]);
				if (query_type < 0 || query_type > 4) {
					System.out.println("Can't recognise this query type\n");
					System.exit(-1);
				}
				this.a_check_ans.get(query_type).total = query_num;
				for (int i = 0; i < query_num; i ++) {
					lineString = checkReader.readLine();
					this.a_check_ans.get(query_type).answers.add(lineString);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (checkReader != null) {
				try {
					checkReader.close();
				} catch (IOException e) {}
			}
		}
		
		//Loading user answer file
		File userAnsFile = new File(this.USER_ANS);
		BufferedReader userReader = null;
		try {
			userReader = new BufferedReader(new FileReader(userAnsFile));
			String lineString = null;
			while ((lineString = userReader.readLine()) != null) {
				String[] params = lineString.split(" ");
				if (params.length != 3) {
					System.out.println("The number of params must be 3");
					System.exit(-1);
				}
				int query_type = Integer.parseInt(params[0]);
				int query_num= Integer.parseInt(params[1]);
				if (query_type < 0 || query_type > 5) {
					System.out.println("Can't recognise this query type\n");
					System.exit(-1);
				}
				this.a_user_ans.get(query_type).total = query_num;
				this.a_user_ans.get(query_type).times = Double.parseDouble(params[2]);
				for (int i = 0; i < query_num; i ++) {
					lineString = userReader.readLine();
					this.a_user_ans.get(query_type).answers.add(lineString);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (userReader != null) {
				try {
					userReader.close();
				} catch (IOException e) {}
			}
		}

		//calculate score
		this.calc_score();
	}

	public void calc_score(){
		File fs = null;
		FileWriter fw = null;
		BufferedWriter bw = null;
		try {
			fs = new File(FILE_SCORE);
			if(!fs.exists()) fs.createNewFile();

			fw = new FileWriter(fs);
			bw = new BufferedWriter(fw);
			
			for (int i = 0; i < this.QUERY_NUM; i++) {
				this.a_check_ans.get(i).times = this.a_user_ans.get(i).times;
				if (this.a_check_ans.get(i).total != this.a_user_ans.get(i).total) {
					this.a_check_ans.get(i).correct = 0;
				}
				int correct = 0;
				for (int j = 0; j < this.a_user_ans.get(i).total; j++) {
					if (this.a_check_ans.get(i).answers.get(j).equals( MD5.Encode(this.a_user_ans.get(i).answers.get(j)))) correct ++;
				}
				this.a_check_ans.get(i).correct = correct;
				String str = String.format("Type:%d, Total: %d, Correct:%d, Times:%f",
						i, this.a_check_ans.get(i).total, this.a_check_ans.get(i).correct, this.a_check_ans.get(i).times);
				String pureStr = String.format("%d %d %d %f", 
						i, this.a_check_ans.get(i).total, this.a_check_ans.get(i).correct, this.a_check_ans.get(i).times);
				bw.write(pureStr);
				bw.newLine();
				bw.flush();
				System.out.println(str);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) { 
			e.printStackTrace();
		} finally {
			try {
				bw.close();
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		Check check = new Check();
		check.run();
	}
}
