package core;

import java.util.*;
import java.io.*;

public class GraphDB{
	/*Input files' path, don't modify!!*/
	private final String friend_file = "./input/friendlist.txt";
	private final String mention_file = "./input/mention.txt";
	private final String microblog_file = "./input/microblog.txt";

	/*Tmp path(Optional), store your temporary files*/
	private final String tmp_path = "./tmp/";

	/*Please read the data here*/
	public GraphDB(){
	}

	/*Public interface, don't modify!!*/
	/*
		How to use Tuple:
		Ceate: Tuple.Tuple2<String, Integer> user = Tuple.tuple("u100000001", 10)
		Using: String uid = user._1(); Integer top = user._2();
	 */
	/*Query 1*/
	public ArrayList<ArrayList<String> > queryOne(
			ArrayList<Tuple.Tuple2<String, Integer> > users) {
		ArrayList<ArrayList<String> > result = new ArrayList<ArrayList<String> >();
		return result;
	}

	/*Query 2*/
	public ArrayList<ArrayList<String> > queryTwo(
			ArrayList<Tuple.Tuple2<String, Integer> > users) {
		ArrayList<ArrayList<String> > result = new ArrayList<ArrayList<String> >();
		return result;
	}

	/*Query 3*/
	public ArrayList<ArrayList<String> > queryThree(
			ArrayList<Tuple.Tuple4<String, String, String, Integer> > users) {
		ArrayList<ArrayList<String> > result = new ArrayList<ArrayList<String> >();
		return result;
	}

	/*Query 4*/
	public ArrayList<ArrayList<String> > queryFour(
			ArrayList<Tuple.Tuple3<String, String, Integer> > users) {
		ArrayList<ArrayList<String> > result = new ArrayList<ArrayList<String> >();
		return result;
	}
}
